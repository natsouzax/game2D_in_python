# game2D_in_python
Trabalho de escola da matéria de algoritmos. Jogo totalmente em python, em 2D, criado por 3 alunos do 1°ano do curso de informática.
